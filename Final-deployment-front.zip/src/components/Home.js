import React from "react";
import './home.css'
import Topbar from "./Topbar";

function Home() {
 
  return (
    <div>
      <Topbar />
    </div>
  );
}

export default Home;