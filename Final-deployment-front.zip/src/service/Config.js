const baseUrl = 'http://10.49.3.7:5001'

const signUp = '/signup'
const login = '/login'
const logout = '/logout'
const dashboard = '/dashboard'


export { baseUrl, signUp, login, logout, dashboard}